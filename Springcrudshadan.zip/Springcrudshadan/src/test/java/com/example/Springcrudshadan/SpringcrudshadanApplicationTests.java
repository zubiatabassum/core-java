package com.example.Springcrudshadan;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringcrudshadanApplicationTests {

	@Test
	void contextLoads() {
	}

}
