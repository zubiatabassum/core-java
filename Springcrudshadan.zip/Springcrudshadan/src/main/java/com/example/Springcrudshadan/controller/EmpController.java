package com.example.Springcrudshadan.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.example.Springcrudshadan.entity.Employee;
import com.example.Springcrudshadan.service.EmployeeServices;

public class EmpController {
	@Autowired
	private EmployeeServices eservice;
	
	@PostMapping ("/addemp")
	public Employee addEmp(@RequestBody Employee emp) {
		return eservice.addEmp(emp);
	}
	
	@GetMapping("/getemp")
	public List<Employee> getEmployee() {
		return eservice.getEmp();
	}
	
	@PutMapping("/updateemp")
	public Employee updateEmployee(@RequestBody Employee emp) {
		return eservice.updateEmp(emp);
		
	}
	
	@DeleteMapping("/deleteemp/(id)")
	public void deleteMapping(@PathVariable Integer id) {
		eservice.deleteEmp(id);
	}
}
