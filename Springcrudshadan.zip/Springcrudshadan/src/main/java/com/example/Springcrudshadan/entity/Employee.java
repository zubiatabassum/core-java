package com.example.Springcrudshadan.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;

//entity/POJO class


@Entity
@Table
public class Employee {
	
	@Id
	private int empid;
	private int empname;
	private String dept;
	public Integer id;
	public int getEmpid() {
		return empid;
	}
	public void setEmpid(int empid) {
		this.empid = empid;
	}
	public int getEmpname() {
		return empname;
	}
	public void setEmpname(int empname) {
		this.empname = empname;
	}
	public String getDept() {
		return dept;
	}
	public void setDept(String dept) {
		this.dept = dept;
	}
	
	

}
