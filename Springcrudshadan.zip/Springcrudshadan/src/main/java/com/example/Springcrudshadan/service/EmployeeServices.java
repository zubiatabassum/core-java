package com.example.Springcrudshadan.service;


import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;

import com.example.Springcrudshadan.entity.Employee;
import com.example.Springcrudshadan.repository.EmployeeRepo;



public class EmployeeServices {
	

	//Postman-->controller-->service-->repository-->DB
	@Autowired
	private EmployeeRepo erepo;
	
	//adding employee details
	public Employee addEmp(Employee emp) {		
         return erepo.save(emp);

}

    //read employee details
    public List<Employee> getEmp() {
        return erepo.findAll();
    }
    
    //update employee
    public Employee updateEmp(Employee emp ) {
    	
    	Integer empid=emp.getEmpid();
    	Employee emp1=erepo.findById(empid).get();
    	emp1.setEmpname(emp.getEmpname());
    	emp1.setDept(emp.getDept());
    	return erepo.save(emp1);
    }   
    //delete employee
    public void deleteEmp(Integer id) {
    	erepo.deleteById(id);
    }
}   