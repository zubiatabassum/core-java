package com.example.Springcrudshadan.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import com.example.Springcrudshadan.entity.Employee;

public interface EmployeeRepo extends JpaRepository<Employee,Integer> {

	Employee save(Optional<Employee> emp1);

}
